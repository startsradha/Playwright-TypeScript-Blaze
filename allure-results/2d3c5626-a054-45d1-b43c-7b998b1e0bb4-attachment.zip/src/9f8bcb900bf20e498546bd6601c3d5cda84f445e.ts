// import {expect,test} from '@playwright/test';
import {googleConfig} from '../config/google.config';
import {Page,expect} from '@playwright/test';
export class GooglePage
{
    private searchtextfield;
    private searchbutton;
    private samsunglink;

    constructor(private page:Page)
    {
        this.searchtextfield=page.getByLabel('Search');
        //this.searchbutton=page.getByRole('button',{name:'Search'});
        this.searchbutton=page.locator('button[type="submit"]')
        this.samsunglink=page.getByRole('link',{name:'Samsung India | Mobile | Tablets | TV | Home Appliances'});
    }
    async gotogoogle():Promise<void>
    {
        await this.page.goto(googleConfig.baseUrl);
        await expect(this.searchtextfield).toBeVisible();
    }
    async search(searchtextfield:string)
    {
        await this.searchtextfield.fill(searchtextfield);
        await this.searchbutton.click();
        await this.samsunglink.click();
    }

}