import {test} from '@playwright/test';
import {GooglePage} from '../pages/googlePage';

test('search google',async ({page})=>
{
  const logingoogle=new GooglePage(page);
  await logingoogle.gotogoogle();
  await logingoogle.search('samsung');
});