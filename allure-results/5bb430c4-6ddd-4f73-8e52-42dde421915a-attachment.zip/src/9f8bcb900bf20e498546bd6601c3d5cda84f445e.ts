// import {expect,test} from '@playwright/test';
// import {googleConfig} from '../config/google.config';
import {Page} from '@playwright/test';
export class GooglePage
{
    private searchtextfield;
    private searchbutton;

    constructor(private page:Page)
    {
        this.searchtextfield=page.getByLabel('Search');
        //this.searchbutton=page.getByRole('button',{name:'Search'});
        this.searchbutton=page.locator('button[type="submit"]')
    }
    async search(searchtextfield:string)
    {
        await this.searchtextfield.fill(searchtextfield);
        await this.searchbutton.click();
    }

}