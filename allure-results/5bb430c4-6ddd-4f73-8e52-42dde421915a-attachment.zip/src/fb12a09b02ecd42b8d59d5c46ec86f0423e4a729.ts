import {test} from '@playwright/test';
import {GooglePage} from '../pages/googlePage';

test('search google',async ({page})=>
{
  const logingoogle=new GooglePage(page);
  logingoogle.search('samsung');
});